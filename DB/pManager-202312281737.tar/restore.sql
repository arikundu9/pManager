--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "pManager";
--
-- Name: pManager; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE "pManager" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


\connect "pManager"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: create_table(character varying); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.create_table(IN tabname character varying)
    LANGUAGE plpgsql
    AS $$
    begin
        IF tabname <> '' THEN
            EXECUTE concat(
                        'CREATE TABLE public.' || tabname || ' (' ,
                        'id bigserial NOT NULL,',
                        'id bigserial NOT NULL,',
                        'created_at timestamp without time zone NOT NULL,',
                        'updated_at timestamp without time zone NULL,',
                        'created_by bigint NOT NULL,',
                        'updated_by bigint NULL,',
                        'CONSTRAINT ' || tabname || '_pk PRIMARY KEY (id)',
                        ');'
                    );
        END IF;
    END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: board; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.board (
    id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint NOT NULL,
    updated_by bigint,
    name character(30) NOT NULL
);


--
-- Name: board_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.board_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: board_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.board_id_seq OWNED BY public.board.id;


--
-- Name: card; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.card (
    id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint NOT NULL,
    updated_by bigint,
    parent_list_id bigint NOT NULL,
    order_value bigint NOT NULL
);


--
-- Name: card_assigned_to_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.card_assigned_to_user (
    id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint NOT NULL,
    updated_by bigint,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL
);


--
-- Name: card_assigned_to_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.card_assigned_to_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: card_assigned_to_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.card_assigned_to_user_id_seq OWNED BY public.card_assigned_to_user.id;


--
-- Name: card_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.card_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: card_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.card_id_seq OWNED BY public.card.id;


--
-- Name: list; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list (
    id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint NOT NULL,
    updated_by bigint,
    parent_board_id bigint NOT NULL,
    order_value bigint NOT NULL
);


--
-- Name: list_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.list_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: list_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.list_id_seq OWNED BY public.list.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint NOT NULL,
    updated_by bigint
);


--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: board id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board ALTER COLUMN id SET DEFAULT nextval('public.board_id_seq'::regclass);


--
-- Name: card id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card ALTER COLUMN id SET DEFAULT nextval('public.card_id_seq'::regclass);


--
-- Name: card_assigned_to_user id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_assigned_to_user ALTER COLUMN id SET DEFAULT nextval('public.card_assigned_to_user_id_seq'::regclass);


--
-- Name: list id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list ALTER COLUMN id SET DEFAULT nextval('public.list_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: board; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3364.dat

--
-- Data for Name: card; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3366.dat

--
-- Data for Name: card_assigned_to_user; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3367.dat

--
-- Data for Name: list; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3370.dat

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3372.dat

--
-- Name: board_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.board_id_seq', 13, true);


--
-- Name: card_assigned_to_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.card_assigned_to_user_id_seq', 1, false);


--
-- Name: card_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.card_id_seq', 1, false);


--
-- Name: list_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.list_id_seq', 1, false);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_id_seq', 1, false);


--
-- Name: board board_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board
    ADD CONSTRAINT board_pk PRIMARY KEY (id);


--
-- Name: card_assigned_to_user card_assigned_to_user_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_assigned_to_user
    ADD CONSTRAINT card_assigned_to_user_pk PRIMARY KEY (id);


--
-- Name: card_assigned_to_user card_assigned_to_user_pk_carduser; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_assigned_to_user
    ADD CONSTRAINT card_assigned_to_user_pk_carduser UNIQUE (card_id, user_id);


--
-- Name: card card_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card
    ADD CONSTRAINT card_pk PRIMARY KEY (id);


--
-- Name: list list_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list
    ADD CONSTRAINT list_pk PRIMARY KEY (id);


--
-- Name: user user_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pk PRIMARY KEY (id);


--
-- Name: card_assigned_to_user card_assigned_to_user_fk_card; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_assigned_to_user
    ADD CONSTRAINT card_assigned_to_user_fk_card FOREIGN KEY (card_id) REFERENCES public.card(id);


--
-- Name: card_assigned_to_user card_assigned_to_user_fk_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_assigned_to_user
    ADD CONSTRAINT card_assigned_to_user_fk_user FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: card card_fk_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card
    ADD CONSTRAINT card_fk_created_by FOREIGN KEY (created_by) REFERENCES public."user"(id);


--
-- Name: card card_fk_in_list; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card
    ADD CONSTRAINT card_fk_in_list FOREIGN KEY (parent_list_id) REFERENCES public.list(id);


--
-- Name: card card_fk_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card
    ADD CONSTRAINT card_fk_updated_by FOREIGN KEY (updated_by) REFERENCES public."user"(id);


--
-- Name: list list_fk_board; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list
    ADD CONSTRAINT list_fk_board FOREIGN KEY (parent_board_id) REFERENCES public.board(id);


--
-- PostgreSQL database dump complete
--

